import vk_api
from vk_api.longpoll import VkLongPoll, VkEventType
import vk_api
from vk_api.longpoll import VkLongPoll, VkEventType
import time
from datetime import datetime, timezone, date,  timedelta
from threading import Timer
from threading import Thread
import typing
import re
import logging
import asyncio
import random
from time import gmtime, strftime
import threading
import json
from typing import Union
#import locale
#locale.setlocale(locale.LC_TIME, 'ru_RU.UTF-8')
import wikipedia
import urllib.request
from bs4 import BeautifulSoup

from tools.messages import messages
from tools.requests import vk_info
from typing import List, Any, Optional

def info_msg_id(peer_id):
    history = vk.method('messages.getHistory', {'count': 1, 'peer_id': peer_id, 'rev': 0})
    msg_id = history['items'][0]['id']
    #nonlocal msg_id
    return msg_id

def write_msg(peer_id, message):
    vk.method('messages.send', {'peer_id': peer_id, 'message': message, 'random_id': random.randint(0, 2048), 'disable_mentions': 1})

def edit_msg(peer_id, message, msg_id, **kwargs):
    vk.method('messages.edit', {'peer_id': peer_id, 'message': message, 'message_id': msg_id, "keep_forward_messages": 1})


async def wiki(delay, peer_id, command, msg_id):
    await asyncio.sleep(delay)
    if ".вики" in command:
    	text = command[5:]
    	wikipedia.set_lang('ru') 
    	fedr = wikipedia.summary(text)  
    	edit_msg(peer_id, fedr, msg_id)  


while True:  
    token =  "вк ме"

    # Авторизуемся как сообщество
    vk = vk_api.VkApi(app_id=6146827, token=token)

    # Работа с сообщениями
    longpoll = VkLongPoll(vk, wait=0)

    # Основной цикл
    for event in longpoll.listen():

        # Если пришло новое сообщение
        if event.type == VkEventType.MESSAGE_NEW:
        
            if event.from_me:
                msg_id = info_msg_id(event.peer_id)
                command = event.text
                try:

                    asyncio.run(wiki(0, event.peer_id, command, msg_id))

                    print(command)
                except Exception as error:
                    print(error)
                continue
            